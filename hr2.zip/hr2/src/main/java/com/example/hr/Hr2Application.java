package com.example.hr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hr2Application {

	public static void main(String[] args) {
		SpringApplication.run(Hr2Application.class, args);
	}

}
